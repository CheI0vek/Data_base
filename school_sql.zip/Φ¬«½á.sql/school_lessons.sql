-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lessons`
--

DROP TABLE IF EXISTS `lessons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lessons` (
  `ID_Lessons_Set` int NOT NULL AUTO_INCREMENT,
  `1_lesson` int NOT NULL,
  `2_lesson` int NOT NULL,
  `3_lesson` int NOT NULL,
  `4_lesson` int NOT NULL,
  `5_lesson` int NOT NULL,
  PRIMARY KEY (`ID_Lessons_Set`,`1_lesson`,`2_lesson`,`3_lesson`,`4_lesson`,`5_lesson`),
  KEY `fk_subject1` (`1_lesson`),
  KEY `fk_subject2` (`2_lesson`),
  KEY `fk_subject3` (`3_lesson`),
  KEY `fk_subject4` (`4_lesson`),
  KEY `fk_subject5` (`5_lesson`),
  CONSTRAINT `fk_subject1` FOREIGN KEY (`1_lesson`) REFERENCES `subjects` (`ID_subject`),
  CONSTRAINT `fk_subject2` FOREIGN KEY (`2_lesson`) REFERENCES `subjects` (`ID_subject`),
  CONSTRAINT `fk_subject3` FOREIGN KEY (`3_lesson`) REFERENCES `subjects` (`ID_subject`),
  CONSTRAINT `fk_subject4` FOREIGN KEY (`4_lesson`) REFERENCES `subjects` (`ID_subject`),
  CONSTRAINT `fk_subject5` FOREIGN KEY (`5_lesson`) REFERENCES `subjects` (`ID_subject`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lessons`
--

LOCK TABLES `lessons` WRITE;
/*!40000 ALTER TABLE `lessons` DISABLE KEYS */;
INSERT INTO `lessons` VALUES (1,1,4,6,5,11),(6,2,5,8,10,1),(2,3,2,1,7,10),(4,4,8,3,5,7),(5,4,1,2,8,9),(10,4,3,2,1,6),(8,6,9,1,3,4),(11,7,3,11,10,1),(7,8,10,2,5,9),(3,9,2,1,4,11),(9,10,5,9,6,8);
/*!40000 ALTER TABLE `lessons` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-17 20:34:53
