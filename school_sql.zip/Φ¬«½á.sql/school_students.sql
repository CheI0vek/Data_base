-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: school
-- ------------------------------------------------------
-- Server version	8.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `ID_student` int NOT NULL AUTO_INCREMENT,
  `Student_FIO` varchar(100) COLLATE utf8mb3_bin NOT NULL,
  `Birthdate` date NOT NULL,
  `ID_Class` int NOT NULL,
  PRIMARY KEY (`ID_student`,`ID_Class`),
  KEY `fk_class` (`ID_Class`),
  CONSTRAINT `fk_class` FOREIGN KEY (`ID_Class`) REFERENCES `class` (`ID_Class`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'Дорохова Арина Ярославовна','2016-01-25',1),(2,'Леонтьев Савва Ярославович','2016-12-14',2),(3,'Новиков Иван Константинович','2015-08-17',4),(4,'Черняева Арина Дмитриевна','2016-09-23',3),(5,'Малышев Илья Фёдорович','2015-03-15',5),(6,'Лебедев Вячеслав Иванович','2013-02-28',12),(7,'Галкина Валерия Степановна','2016-08-05',3),(8,'Алексеев Роман Иванович','2015-07-02',4),(9,'Смирнова Вероника Назаровна','2014-05-06',8),(10,'Казакова Полина Львовна','2013-11-11',10),(11,'Кулагин Александр Даниилович','2015-12-09',6),(12,'Марков Руслан Маркович','2014-01-30',7),(13,'Новикова Ксения Михайловна','2016-12-31',2),(14,'Малышева Дарья Львовна','2013-09-04',12),(15,'Козырев Иван Артёмович','2013-06-12',11),(16,'Суслов Мирон Александрович','2015-05-23',5),(17,'Лебедев Игорь Ярославович','2005-10-20',10),(18,'Колесников Алексей Артёмович','2015-11-15',6),(19,'Богданова Ксения Яновна','2016-02-06',1),(20,'Николаев Святослав Михайлович','2014-06-19',7),(21,'Ларина Полина Тимофеевна','2014-02-08',9),(22,'Новикова Анастасия Родионовна','2013-08-01',11),(23,'Агеев Максим Дмитриевич','2014-12-10',8),(24,'Алексеев Андрей Никитич','2014-02-11',9);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-17 20:34:53
